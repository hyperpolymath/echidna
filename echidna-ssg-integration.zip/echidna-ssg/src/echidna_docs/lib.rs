// SPDX-License-Identifier: MIT AND Palimpsest-0.6
// SPDX-FileCopyrightText: 2024-2025 ECHIDNA Project Contributors

//! # echidna-docs
//! 
//! Static site generator for formal proof content.
//! 
//! Unlike conventional SSGs that process Markdown, `echidna-docs` understands
//! theorem prover source files and renders them with semantic awareness:
//! 
//! - Syntax highlighting that understands types, not just tokens
//! - Proof dependency graphs
//! - Aspect-tagged navigation (algebraic, topological, etc.)
//! - Cross-prover theorem linking
//! 
//! ## Supported Formats
//! 
//! | Format    | Extension | Status      |
//! |-----------|-----------|-------------|
//! | Agda      | `.agda`   | ✓ Active    |
//! | Lean      | `.lean`   | ✓ Active    |
//! | Coq/Rocq  | `.v`      | ✓ Active    |
//! | Isabelle  | `.thy`    | ◐ Partial   |
//! | Z3        | `.smt2`   | ◐ Partial   |
//! | Metamath  | `.mm`     | ○ Planned   |
//! | HOL Light | `.ml`     | ○ Planned   |
//! | Mizar     | `.miz`    | ○ Planned   |
//! 
//! ## Usage
//! 
//! ```bash
//! echidna-docs build --source content/ --output site/
//! echidna-docs serve --port 8080
//! echidna-docs graph --output deps.svg
//! ```

use std::path::PathBuf;

pub mod aspect;
pub mod config;
pub mod graph;
pub mod prover;
pub mod render;
pub mod site;

/// Configuration for site generation
#[derive(Debug, Clone)]
pub struct SiteConfig {
    /// Source directory containing proof files
    pub source: PathBuf,
    /// Output directory for generated site
    pub output: PathBuf,
    /// Site title
    pub title: String,
    /// Base URL for generated links
    pub base_url: String,
    /// Enabled prover backends
    pub provers: Vec<ProverKind>,
    /// Aspect tagging configuration
    pub aspects: AspectConfig,
    /// Template directory (optional, uses defaults if not set)
    pub templates: Option<PathBuf>,
}

impl Default for SiteConfig {
    fn default() -> Self {
        Self {
            source: PathBuf::from("content"),
            output: PathBuf::from("site"),
            title: String::from("ECHIDNA Proofs"),
            base_url: String::from("/"),
            provers: vec![
                ProverKind::Agda,
                ProverKind::Lean,
                ProverKind::Coq,
            ],
            aspects: AspectConfig::default(),
            templates: None,
        }
    }
}

/// Supported theorem prover backends
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ProverKind {
    Agda,
    Lean,
    Coq,
    Isabelle,
    Z3,
    CVC5,
    Metamath,
    HolLight,
    Mizar,
    Pvs,
    Acl2,
    Hol4,
}

impl ProverKind {
    /// File extensions associated with this prover
    pub fn extensions(&self) -> &'static [&'static str] {
        match self {
            ProverKind::Agda => &["agda", "lagda", "lagda.md", "lagda.rst"],
            ProverKind::Lean => &["lean"],
            ProverKind::Coq => &["v"],
            ProverKind::Isabelle => &["thy"],
            ProverKind::Z3 => &["smt2", "z3"],
            ProverKind::CVC5 => &["smt2", "cvc5"],
            ProverKind::Metamath => &["mm"],
            ProverKind::HolLight => &["ml"],
            ProverKind::Mizar => &["miz"],
            ProverKind::Pvs => &["pvs"],
            ProverKind::Acl2 => &["lisp", "acl2"],
            ProverKind::Hol4 => &["sml"],
        }
    }

    /// Human-readable name
    pub fn display_name(&self) -> &'static str {
        match self {
            ProverKind::Agda => "Agda",
            ProverKind::Lean => "Lean",
            ProverKind::Coq => "Coq/Rocq",
            ProverKind::Isabelle => "Isabelle/HOL",
            ProverKind::Z3 => "Z3",
            ProverKind::CVC5 => "CVC5",
            ProverKind::Metamath => "Metamath",
            ProverKind::HolLight => "HOL Light",
            ProverKind::Mizar => "Mizar",
            ProverKind::Pvs => "PVS",
            ProverKind::Acl2 => "ACL2",
            ProverKind::Hol4 => "HOL4",
        }
    }
}

/// Aspect tagging configuration
#[derive(Debug, Clone)]
pub struct AspectConfig {
    /// Enable automatic aspect detection
    pub auto_detect: bool,
    /// Custom aspect definitions
    pub custom_aspects: Vec<CustomAspect>,
    /// Aspects to exclude from navigation
    pub excluded: Vec<String>,
}

impl Default for AspectConfig {
    fn default() -> Self {
        Self {
            auto_detect: true,
            custom_aspects: vec![],
            excluded: vec![],
        }
    }
}

/// User-defined aspect category
#[derive(Debug, Clone)]
pub struct CustomAspect {
    /// Aspect identifier (kebab-case)
    pub id: String,
    /// Display name
    pub name: String,
    /// Keywords that trigger this aspect
    pub keywords: Vec<String>,
    /// CSS colour for UI
    pub colour: String,
}

/// A proof file with extracted metadata
#[derive(Debug, Clone)]
pub struct ProofFile {
    /// Source path relative to content root
    pub path: PathBuf,
    /// Detected prover
    pub prover: ProverKind,
    /// Extracted title (from module name or first definition)
    pub title: String,
    /// Detected aspects
    pub aspects: Vec<String>,
    /// Dependencies on other proof files
    pub dependencies: Vec<PathBuf>,
    /// Definitions exported by this file
    pub exports: Vec<Definition>,
    /// Raw source content
    pub source: String,
}

/// A definition within a proof file
#[derive(Debug, Clone)]
pub struct Definition {
    /// Definition name
    pub name: String,
    /// Kind (theorem, lemma, definition, axiom, etc.)
    pub kind: DefinitionKind,
    /// Type signature (if available)
    pub signature: Option<String>,
    /// Line number in source
    pub line: usize,
    /// Associated aspects
    pub aspects: Vec<String>,
}

/// Kinds of definitions in proof files
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DefinitionKind {
    Theorem,
    Lemma,
    Corollary,
    Proposition,
    Definition,
    Axiom,
    Postulate,
    Record,
    Inductive,
    Function,
    Instance,
    Module,
    Other,
}

/// Build a site from proof content
pub fn build_site(config: &SiteConfig) -> Result<BuildResult, BuildError> {
    // Phase 1: Discover proof files
    let files = site::discover_files(&config.source, &config.provers)?;
    
    // Phase 2: Parse and extract metadata
    let proofs: Vec<ProofFile> = files
        .into_iter()
        .filter_map(|path| prover::parse_file(&path, config).ok())
        .collect();
    
    // Phase 3: Build dependency graph
    let graph = graph::build_dependency_graph(&proofs);
    
    // Phase 4: Detect aspects
    let proofs = aspect::tag_aspects(proofs, &config.aspects);
    
    // Phase 5: Render HTML
    let pages = render::render_all(&proofs, &graph, config)?;
    
    // Phase 6: Generate index and navigation
    let index = render::render_index(&proofs, &graph, config)?;
    
    // Phase 7: Write output
    site::write_output(&pages, &index, config)?;
    
    Ok(BuildResult {
        files_processed: proofs.len(),
        pages_generated: pages.len() + 1, // +1 for index
        aspects_detected: proofs.iter()
            .flat_map(|p| p.aspects.iter())
            .collect::<std::collections::HashSet<_>>()
            .len(),
        graph_edges: graph.edge_count(),
    })
}

/// Result of a successful build
#[derive(Debug)]
pub struct BuildResult {
    pub files_processed: usize,
    pub pages_generated: usize,
    pub aspects_detected: usize,
    pub graph_edges: usize,
}

/// Errors that can occur during build
#[derive(Debug, thiserror::Error)]
pub enum BuildError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    
    #[error("Parse error in {file}: {message}")]
    Parse { file: PathBuf, message: String },
    
    #[error("Template error: {0}")]
    Template(String),
    
    #[error("Configuration error: {0}")]
    Config(String),
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn prover_extensions_non_empty() {
        for prover in [
            ProverKind::Agda,
            ProverKind::Lean,
            ProverKind::Coq,
        ] {
            assert!(!prover.extensions().is_empty());
        }
    }

    #[test]
    fn default_config_valid() {
        let config = SiteConfig::default();
        assert!(!config.provers.is_empty());
    }
}
